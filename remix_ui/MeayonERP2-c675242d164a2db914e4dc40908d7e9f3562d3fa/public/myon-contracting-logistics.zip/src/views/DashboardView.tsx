import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  TrendingUp,
  Truck,
  Building2,
  AlertTriangle,
  Scale,
  DollarSign,
  PieChart as PieIcon,
  Calendar,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  ShieldAlert,
  Sparkles,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from 'recharts';
import { formatCurrency, formatNumber, formatTonnage, getMonthName } from '../utils/formatters';

const CHART_COLORS = ['#4F46E5', '#7C3AED', '#2563EB', '#059669', '#D97706', '#DC2626', '#8B5CF6'];

export const DashboardView: React.FC<{ onNavigateToTab?: (tab: any) => void }> = ({ onNavigateToTab }) => {
  const { accessibleOperations, kpis, language, currentUser, canAccessFinancials } = useApp();
  const isAr = language === 'ar';

  const [selectedMonth, setSelectedMonth] = useState<number | 'ALL'>('ALL');

  // Filter operations based on selected month
  const filteredOps = useMemo(() => {
    if (selectedMonth === 'ALL') return accessibleOperations;
    return accessibleOperations.filter((op) => op.operation_month === Number(selectedMonth));
  }, [accessibleOperations, selectedMonth]);

  // 1. Sales by Customer Data
  const salesByCustomerData = useMemo(() => {
    const map: Record<string, { name: string; sales: number; tonnage: number }> = {};
    filteredOps.forEach((op) => {
      const shortName = op.destination_customer.split(' ')[1] || op.destination_customer.slice(0, 12);
      if (!map[shortName]) {
        map[shortName] = { name: shortName, sales: 0, tonnage: 0 };
      }
      map[shortName].sales += op.sales_amount;
      map[shortName].tonnage += op.qty_delivered;
    });
    return Object.values(map).sort((a, b) => b.sales - a.sales);
  }, [filteredOps]);

  // 2. Purchases by Crusher Data
  const purchasesByCrusherData = useMemo(() => {
    const map: Record<string, { name: string; cost: number; tonnage: number }> = {};
    filteredOps.forEach((op) => {
      const shortName = op.loading_source.replace('كسارة ', '').replace(' Crusher', '');
      if (!map[shortName]) {
        map[shortName] = { name: shortName, cost: 0, tonnage: 0 };
      }
      map[shortName].cost += op.purchases_cost;
      map[shortName].tonnage += op.qty_loaded;
    });
    return Object.values(map).sort((a, b) => b.cost - a.cost);
  }, [filteredOps]);

  // 3. Transporter Wastage Risk Ranking (Drivers with highest tonnage loss)
  const transporterWastageData = useMemo(() => {
    const map: Record<string, { name: string; wastageTons: number; trips: number; totalLoaded: number }> = {};
    filteredOps.forEach((op) => {
      const shortName = op.transporter_name.split(' ')[0] + ' ' + (op.transporter_name.split(' ')[1] || '');
      if (!map[shortName]) {
        map[shortName] = { name: shortName, wastageTons: 0, trips: 0, totalLoaded: 0 };
      }
      map[shortName].wastageTons += op.qty_wastage;
      map[shortName].trips += 1;
      map[shortName].totalLoaded += op.qty_loaded;
    });

    return Object.values(map)
      .map((item) => ({
        ...item,
        wastagePercent: item.totalLoaded > 0 ? Number(((item.wastageTons / item.totalLoaded) * 100).toFixed(2)) : 0,
        wastageTons: Number(item.wastageTons.toFixed(2)),
      }))
      .sort((a, b) => b.wastageTons - a.wastageTons);
  }, [filteredOps]);

  // 4. Customer Delivered Volume Distribution (Pie Chart)
  const customerVolumePieData = useMemo(() => {
    const map: Record<string, number> = {};
    filteredOps.forEach((op) => {
      const name = op.destination_customer.split(' ')[1] || op.destination_customer.slice(0, 10);
      map[name] = (map[name] || 0) + op.qty_delivered;
    });
    return Object.entries(map).map(([name, value]) => ({
      name,
      value: Number(value.toFixed(1)),
    }));
  }, [filteredOps]);

  // 5. 12-Month Revenue & Tonnage Matrix (Dynamic Pivot Matrix)
  const monthlyMatrix = useMemo(() => {
    const months = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
    return months.map((m) => {
      const monthOps = accessibleOperations.filter((op) => op.operation_month === m);
      const sales = monthOps.reduce((acc, curr) => acc + curr.sales_amount, 0);
      const purchases = monthOps.reduce((acc, curr) => acc + curr.purchases_cost, 0);
      const profit = monthOps.reduce((acc, curr) => acc + curr.net_profit, 0);
      const deliveredTonnage = monthOps.reduce((acc, curr) => acc + curr.qty_delivered, 0);
      const wastage = monthOps.reduce((acc, curr) => acc + curr.qty_wastage, 0);
      const trips = monthOps.length;

      return {
        month: m,
        monthName: getMonthName(m, language),
        sales,
        purchases,
        profit,
        deliveredTonnage,
        wastage,
        trips,
      };
    });
  }, [accessibleOperations, language]);

  return (
    <div className="space-y-6" id="executive-dashboard-view">
      {/* Top Filter & Welcome Header */}
      <div className="flex flex-col justify-between gap-4 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs sm:flex-row sm:items-center">
        <div>
          <h1 className="text-xl font-black text-slate-900">
            {isAr ? 'لوحة القيادة التنفيذية والمؤشرات المالية' : 'Executive Operations & Financial Dashboard'}
          </h1>
          <p className="text-xs text-slate-500">
            {isAr
              ? 'متابعة حية لتوريدات الكسارات، فاقد النقل، والمطالبات الشهرية لشركة ميون'
              : 'Live quarry haulage metrics, material loss risk, and monthly revenue ledgers'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-700">
            <Calendar className="h-4 w-4 text-orange-600" />
            <span className="font-semibold">{isAr ? 'الفترة:' : 'Filter Month:'}</span>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value === 'ALL' ? 'ALL' : Number(e.target.value))}
              className="bg-transparent font-bold text-orange-950 focus:outline-none"
            >
              <option value="ALL">{isAr ? 'كافة الشهور (2026)' : 'All Months (2026)'}</option>
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((m) => (
                <option key={m} value={m}>
                  {getMonthName(m, language)} 2026
                </option>
              ))}
            </select>
          </div>

          {onNavigateToTab && currentUser.role !== 'Guest' && (
            <button
              onClick={() => onNavigateToTab('ai-insights')}
              className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-600 px-3.5 py-1.5 text-xs font-bold text-white shadow-xs hover:opacity-95"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>{isAr ? 'التقرير الذكي' : 'AI Analysis'}</span>
            </button>
          )}
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Total Sales */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">
              {isAr ? 'إجمالي المبيعات (بدون ضريبة)' : 'Gross Sales (Excl. VAT)'}
            </span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-orange-50 text-orange-600">
              <DollarSign className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 text-xl font-black text-slate-900">
            {canAccessFinancials
              ? formatCurrency(kpis.totalSales, language)
              : isAr
              ? '*** محمي'
              : '*** Protected'}
          </div>
          <div className="mt-1 flex items-center gap-1 text-[11px] text-emerald-600 font-semibold">
            <ArrowUpRight className="h-3.5 w-3.5" />
            <span>{isAr ? '+14.2% مقارنة بالشهر السابق' : '+14.2% MoM Growth'}</span>
          </div>
        </div>

        {/* Net Operating Profit */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">
              {isAr ? 'صافي هامش الربح التشغيلي' : 'Net Operating Profit'}
            </span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
              <TrendingUp className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 text-xl font-black text-emerald-700">
            {canAccessFinancials
              ? formatCurrency(kpis.netOperatingProfit, language)
              : isAr
              ? '*** محمي'
              : '*** Protected'}
          </div>
          <div className="mt-1 text-[11px] text-slate-500 font-medium">
            {canAccessFinancials && (
              <span>
                {isAr ? 'نسبة الهامش:' : 'Margin:'}{' '}
                <strong className="text-emerald-800">{kpis.profitMarginPercent.toFixed(1)}%</strong>
              </span>
            )}
          </div>
        </div>

        {/* Total Delivered Tonnage */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">
              {isAr ? 'إجمالي الحمولات المستلمة' : 'Delivered Tonnage'}
            </span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-blue-50 text-blue-600">
              <Scale className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 text-xl font-black text-slate-900">
            {formatTonnage(kpis.totalDeliveredTonnage, language)}
          </div>
          <div className="mt-1 text-[11px] text-slate-500">
            <span>
              {isAr ? 'إجمالي الرحلات:' : 'Total Trips:'} <strong>{kpis.totalTrips}</strong> {isAr ? 'رحلة' : 'trips'}
            </span>
          </div>
        </div>

        {/* Total Wastage Loss */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">
              {isAr ? 'إجمالي فاقد النقل (Wastage)' : 'Cumulative Haulage Loss'}
            </span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-rose-50 text-rose-600">
              <AlertTriangle className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 text-xl font-black text-rose-600">
            {formatTonnage(kpis.totalWastageTonnage, language)}
          </div>
          <div className="mt-1 flex items-center gap-1.5 text-[11px] text-slate-500">
            <span className="rounded-md bg-rose-50 px-1.5 py-0.5 font-bold text-rose-700">
              {kpis.overallWastagePercent.toFixed(2)}% {isAr ? 'من المحمل' : 'of loaded'}
            </span>
            <span>{isAr ? 'متوسط الفاقد' : 'avg loss'}</span>
          </div>
        </div>
      </div>

      {/* Primary Analytics Charts Row */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Chart 1: Sales by Customer */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {isAr ? 'حجم المبيعات حسب العميل (ر.س)' : 'Sales Revenue by Customer (SAR)'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {isAr ? 'أعلى العملاء إيراداً واستلاماً للمواد' : 'Top revenue generating clients'}
              </p>
            </div>
            <span className="rounded-lg bg-orange-50 px-2 py-1 text-[10px] font-bold text-orange-700">
              {isAr ? 'رسم بياني شريطي' : 'Bar Chart'}
            </span>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={salesByCustomerData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  formatter={(val: any) => [formatCurrency(Number(val), language), isAr ? 'المبيعات' : 'Sales']}
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #E2E8F0' }}
                />
                <Bar dataKey="sales" fill="#4F46E5" radius={[6, 6, 0, 0]} name={isAr ? 'المبيعات' : 'Sales'} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Purchases by Crusher */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {isAr ? 'مشتريات الكسارات ومصادر التحميل (ر.س)' : 'Crusher Purchases Cost (SAR)'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {isAr ? 'توزيع التكلفة التوريدية على المقالع' : 'Supply procurement breakdown per quarry'}
              </p>
            </div>
            <span className="rounded-lg bg-amber-50 px-2 py-1 text-[10px] font-bold text-purple-700">
              {isAr ? 'أعمدة توريد' : 'Column Chart'}
            </span>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={purchasesByCrusherData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  formatter={(val: any) => [formatCurrency(Number(val), language), isAr ? 'التكلفة' : 'Cost']}
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #E2E8F0' }}
                />
                <Bar dataKey="cost" fill="#7C3AED" radius={[6, 6, 0, 0]} name={isAr ? 'المشتريات' : 'Cost'} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Secondary Charts Row */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Chart 3: Transporter Wastage Risk Ranking (Horizontal Bar Chart) */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {isAr ? 'تصنيف مخاطر فاقد الناقلين (Wastage Risk Ranking)' : 'Transporter Loss & Risk Ranking'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {isAr ? 'ترتيب المقاولين والسائقين حسب إجمالي أطنان الفاقد المفقودة' : 'Ranking transporters by missing tonnage'}
              </p>
            </div>
            <div className="flex items-center gap-1 text-xs font-semibold text-rose-600">
              <ShieldAlert className="h-4 w-4" />
              <span>{isAr ? 'مراقبة الاحتيال' : 'Loss Audit'}</span>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                layout="vertical"
                data={transporterWastageData}
                margin={{ top: 5, right: 20, left: 40, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#E2E8F0" />
                <XAxis type="number" tick={{ fontSize: 11 }} />
                <YAxis dataKey="name" type="category" tick={{ fontSize: 11 }} width={120} />
                <Tooltip
                  formatter={(val: any) => [`${val} ${isAr ? 'طن مفقود' : 'Tons Loss'}`, isAr ? 'إجمالي الفاقد' : 'Wastage']}
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #E2E8F0' }}
                />
                <Bar dataKey="wastageTons" fill="#EF4444" radius={[0, 6, 6, 0]} name={isAr ? 'الفاقد (طن)' : 'Loss (Tons)'} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Customer Delivered Volume Distribution (Pie/Donut) */}
        <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs">
          <div className="mb-2">
            <h3 className="text-sm font-bold text-slate-900">
              {isAr ? 'توزيع حمولات العملاء' : 'Customer Volume Share'}
            </h3>
            <p className="text-[11px] text-slate-500">
              {isAr ? 'نسبة التوريدات الصافية' : 'Delivered tonnage share'}
            </p>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={customerVolumePieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {customerVolumePieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any) => [`${val} ${isAr ? 'طن' : 'Tons'}`, isAr ? 'الكمية' : 'Volume']}
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #E2E8F0' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="flex flex-wrap justify-center gap-2 text-[10px]">
            {customerVolumePieData.map((entry, i) => (
              <div key={entry.name} className="flex items-center gap-1 text-slate-600">
                <span
                  className="h-2.5 w-2.5 rounded-full"
                  style={{ backgroundColor: CHART_COLORS[i % CHART_COLORS.length] }}
                />
                <span>{entry.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 5. 12-Month Revenue & Tonnage Dynamic Matrix Pivot Grid */}
      <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs">
        <div className="mb-4 flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              {isAr ? 'مصفوفة الإيرادات والحمولات السنوية (12-Month Performance Matrix)' : '12-Month Financial & Volume Matrix'}
            </h3>
            <p className="text-[11px] text-slate-500">
              {isAr
                ? 'جدول بياني محوري لتحليل تدفقات المبيعات، تكاليف الكسارات، وصافي الأرباح شهرياً'
                : 'Dynamic pivot breakdown of monthly sales, crusher costs, and margins'}
            </p>
          </div>
          <span className="rounded-lg bg-orange-50 px-2.5 py-1 text-xs font-bold text-orange-700">
            {isAr ? 'سنة 2026 المالية' : 'Fiscal Year 2026'}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-bold text-slate-700">
                <th className="py-3 px-3">{isAr ? 'الشهر' : 'Month'}</th>
                <th className="py-3 px-3">{isAr ? 'عدد الرحلات' : 'Trips'}</th>
                <th className="py-3 px-3">{isAr ? 'الحمولة المستلمة (طن)' : 'Delivered Tonnage'}</th>
                <th className="py-3 px-3">{isAr ? 'الفاقد (طن)' : 'Wastage (Tons)'}</th>
                <th className="py-3 px-3">{isAr ? 'إجمالي المبيعات' : 'Total Sales'}</th>
                <th className="py-3 px-3">{isAr ? 'مشتريات الكسارات' : 'Crusher Costs'}</th>
                <th className="py-3 px-3">{isAr ? 'صافي الربح' : 'Net Margin'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {monthlyMatrix.map((row) => (
                <tr key={row.month} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-slate-900">{row.monthName}</td>
                  <td className="py-2.5 px-3 text-slate-600">{row.trips}</td>
                  <td className="py-2.5 px-3 font-semibold text-slate-800">
                    {row.deliveredTonnage > 0 ? formatTonnage(row.deliveredTonnage, language) : '-'}
                  </td>
                  <td className="py-2.5 px-3">
                    {row.wastage > 0 ? (
                      <span className="font-semibold text-rose-600">
                        {formatTonnage(row.wastage, language)}
                      </span>
                    ) : (
                      '-'
                    )}
                  </td>
                  <td className="py-2.5 px-3 font-semibold text-slate-900">
                    {canAccessFinancials && row.sales > 0 ? formatCurrency(row.sales, language) : '-'}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">
                    {canAccessFinancials && row.purchases > 0 ? formatCurrency(row.purchases, language) : '-'}
                  </td>
                  <td className="py-2.5 px-3 font-bold text-emerald-700">
                    {canAccessFinancials && row.profit > 0 ? formatCurrency(row.profit, language) : '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
