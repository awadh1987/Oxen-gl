import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Sidebar, ActiveTab } from './components/Sidebar';
import { ProtectedRoute } from './components/ProtectedRoute';
import { DashboardView } from './views/DashboardView';
import { OperationsLogView } from './views/OperationsLogView';
import { CustomerInvoicingView } from './views/CustomerInvoicingView';
import { CrusherLedgerView } from './views/CrusherLedgerView';
import { TransporterPerformanceView } from './views/TransporterPerformanceView';
import { AIOperationsView } from './views/AIOperationsView';
import { ExecutiveAdminView } from './views/ExecutiveAdminView';
import { MasterDataView } from './views/MasterDataView';
import { FinancialVouchersView } from './views/FinancialVouchersView';
import { LoginView } from './views/LoginView';
import { PublicSharedInvoiceView } from './views/PublicSharedInvoiceView';
import { AIAssistantWidget } from './components/AIAssistantWidget';
import { ExportPrintModal, ExportDocType } from './components/ExportPrintModal';
import { Menu, X } from 'lucide-react';
import { UserRole } from './types';

function AppContent() {
  const { language, currentUser, brandConfig, isDriverMode } = useApp();
  const isAr = language === 'ar';

  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isAIChatOpen, setIsAIChatOpen] = useState(false);
  const [isExportPrintModalOpen, setIsExportPrintModalOpen] = useState(false);

  // If driver mode is turned on and current tab is restricted, switch to operations
  useEffect(() => {
    if (isDriverMode && activeTab !== 'operations' && activeTab !== 'transporters') {
      setActiveTab('operations');
    }
  }, [isDriverMode, activeTab]);

  // Derive default document type based on current active tab
  const defaultDocTypeForTab: ExportDocType = React.useMemo(() => {
    switch (activeTab) {
      case 'operations':
        return 'daily-operations';
      case 'invoicing':
        return 'vat-invoice';
      case 'crushers':
        return 'crusher-statement';
      case 'transporters':
        return 'transporter-shrinkage';
      case 'vouchers':
        return 'financial-vouchers';
      default:
        return 'vat-invoice';
    }
  }, [activeTab]);

  // Check URL for public shared invoice link (?shared_invoice=INV-2026-08-1048&token=...)
  const [sharedInvoiceParams, setSharedInvoiceParams] = useState<{
    invoiceNumber: string;
    token?: string;
  } | null>(() => {
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      const sharedInv = urlParams.get('shared_invoice');
      const token = urlParams.get('token') || undefined;
      if (sharedInv) {
        return { invoiceNumber: sharedInv, token };
      }
    }
    return null;
  });

  // If a public shared invoice link was accessed, render the standalone auditor view
  if (sharedInvoiceParams) {
    return (
      <PublicSharedInvoiceView
        invoiceNumber={sharedInvoiceParams.invoiceNumber}
        token={sharedInvoiceParams.token}
        onBackToPortal={() => {
          // Clear query params and show login/portal
          window.history.replaceState({}, document.title, window.location.pathname);
          setSharedInvoiceParams(null);
        }}
      />
    );
  }

  if (!isLoggedIn) {
    return <LoginView onLoginSuccess={() => setIsLoggedIn(true)} />;
  }

  // View-level RBAC role mappings
  const viewRoleRequirements: Record<ActiveTab, UserRole[] | undefined> = {
    dashboard: ['Admin', 'COO', 'Accountant', 'Data_Entry', 'Guest'],
    operations: ['Admin', 'COO', 'Accountant', 'Data_Entry', 'Guest'],
    invoicing: ['Admin', 'COO', 'Accountant', 'Guest'],
    vouchers: ['Admin', 'COO', 'Accountant'],
    crushers: ['Admin', 'COO', 'Accountant'],
    transporters: ['Admin', 'COO', 'Accountant', 'Data_Entry'],
    'ai-insights': ['Admin', 'COO', 'Accountant'],
    'executive-admin': ['Admin', 'COO'],
    'master-data': ['Admin', 'COO'],
  };

  const renderActiveViewContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView onNavigateToTab={(tab) => setActiveTab(tab)} />;
      case 'operations':
        return <OperationsLogView />;
      case 'invoicing':
        return <CustomerInvoicingView />;
      case 'vouchers':
        return <FinancialVouchersView />;
      case 'crushers':
        return <CrusherLedgerView />;
      case 'transporters':
        return <TransporterPerformanceView />;
      case 'ai-insights':
        return <AIOperationsView />;
      case 'executive-admin':
        return <ExecutiveAdminView />;
      case 'master-data':
        return <MasterDataView />;
      default:
        return <DashboardView onNavigateToTab={(tab) => setActiveTab(tab)} />;
    }
  };

  return (
    <div
      id="meayon-erp-app-root"
      dir={isAr ? 'rtl' : 'ltr'}
      className="min-h-screen bg-neutral-50/80 font-sans text-neutral-900 antialiased selection:bg-[#F05627] selection:text-white relative"
    >
      {/* Top Corporate Navbar */}
      <Navbar
        onOpenAIModal={() => setIsAIChatOpen(true)}
        onOpenExportPrintModal={() => setIsExportPrintModalOpen(true)}
        onLogout={() => setIsLoggedIn(false)}
      />

      <div className="flex">
        {/* Responsive Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          isOpenMobile={isMobileMenuOpen}
          onCloseMobile={() => setIsMobileMenuOpen(false)}
        />

        {/* Main Content Area guarded by ProtectedRoute */}
        <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8">
          {/* Mobile Menu Toggle Bar */}
          <div className="mb-4 flex items-center justify-between lg:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="flex items-center gap-2 rounded-xl border border-neutral-200 bg-white px-3 py-2 text-xs font-bold text-neutral-700 shadow-xs"
            >
              {isMobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
              <span>{isAr ? 'القائمة الرئيسية' : 'Menu'}</span>
            </button>

            <span className="text-xs font-black text-[#F05627]">
              {isAr ? brandConfig.companyNameAr : brandConfig.companyNameEn}
            </span>
          </div>

          {/* Current Active View Component wrapped in ProtectedRoute */}
          <ProtectedRoute
            allowedRoles={viewRoleRequirements[activeTab]}
            isLoggedIn={isLoggedIn}
            onRequireLogin={() => setIsLoggedIn(false)}
            onNavigateHome={() => setActiveTab('dashboard')}
          >
            {renderActiveViewContent()}
          </ProtectedRoute>
        </main>
      </div>

      {/* Global Live Preview & Print/Export Modal */}
      <ExportPrintModal
        isOpen={isExportPrintModalOpen}
        onClose={() => setIsExportPrintModalOpen(false)}
        initialDocType={defaultDocTypeForTab}
      />

      {/* Persistent AI Assistant Widget */}
      <AIAssistantWidget
        isOpenExternal={isAIChatOpen}
        onCloseExternal={() => setIsAIChatOpen(false)}
        onNavigateToTab={(tab) => {
          setActiveTab(tab);
          setIsAIChatOpen(false);
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
