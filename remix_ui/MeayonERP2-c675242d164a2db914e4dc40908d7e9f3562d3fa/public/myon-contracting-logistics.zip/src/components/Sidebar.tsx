import React from 'react';
import { useApp } from '../context/AppContext';
import {
  LayoutDashboard,
  Truck,
  FileSpreadsheet,
  Building2,
  TrendingDown,
  Sparkles,
  Database,
  ShieldCheck,
  Lock,
  Receipt,
} from 'lucide-react';

export type ActiveTab =
  | 'dashboard'
  | 'operations'
  | 'invoicing'
  | 'vouchers'
  | 'crushers'
  | 'transporters'
  | 'ai-insights'
  | 'executive-admin'
  | 'master-data';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isOpenMobile = false,
  onCloseMobile,
}) => {
  const { currentUser, language, canAccessFinancials, kpis, isDriverMode, toggleDriverMode, setIsDriverMode } = useApp();
  const isAr = language === 'ar';

  const menuItems = [
    {
      id: 'dashboard' as ActiveTab,
      labelAr: 'لوحة القيادة والمؤشرات',
      labelEn: 'Executive Dashboard',
      icon: LayoutDashboard,
      roles: ['Admin', 'COO', 'Accountant', 'Data_Entry', 'Guest'],
      badge: isAr ? 'رئيسي' : 'Core',
    },
    {
      id: 'operations' as ActiveTab,
      labelAr: 'قيد العمليات اليومية',
      labelEn: 'Daily Operations Entry',
      icon: Truck,
      roles: ['Admin', 'COO', 'Accountant', 'Data_Entry', 'Guest'],
      badge: isDriverMode ? (isAr ? 'نشط' : 'Active') : null,
    },
    {
      id: 'invoicing' as ActiveTab,
      labelAr: 'الفواتير الضريبية للعملاء',
      labelEn: 'Customer Invoicing',
      icon: FileSpreadsheet,
      roles: ['Admin', 'COO', 'Accountant', 'Guest'],
      badge: 'ZATCA',
    },
    {
      id: 'vouchers' as ActiveTab,
      labelAr: 'سندات القبض والصرف',
      labelEn: 'Payment & Receipt Vouchers',
      icon: Receipt,
      roles: ['Admin', 'COO', 'Accountant'],
      badge: isAr ? 'سندات' : 'Vouchers',
    },
    {
      id: 'crushers' as ActiveTab,
      labelAr: 'حسابات الكسارات (دائن/مدين)',
      labelEn: 'Crusher Payables Ledger',
      icon: Building2,
      roles: ['Admin', 'COO', 'Accountant'],
      badge: null,
    },
    {
      id: 'transporters' as ActiveTab,
      labelAr: 'أداء الناقلين ورصد الفاقد',
      labelEn: 'Transporter Loss & Audit',
      icon: TrendingDown,
      roles: ['Admin', 'COO', 'Accountant', 'Data_Entry'],
      badge: isAr ? 'تتبع الفاقد' : 'Wastage',
    },
    {
      id: 'ai-insights' as ActiveTab,
      labelAr: 'الذكاء التشغيلي ومكافحة الاحتيال',
      labelEn: 'AI Operations & Audit',
      icon: Sparkles,
      roles: ['Admin', 'COO', 'Accountant'],
      badge: 'AI Suite',
    },
    {
      id: 'executive-admin' as ActiveTab,
      labelAr: 'لوحة الإدارة والاعتمادات',
      labelEn: 'Executive Approvals & Audit',
      icon: ShieldCheck,
      roles: ['Admin', 'COO'],
      badge: kpis.pendingApprovalsCount > 0 ? `${kpis.pendingApprovalsCount} ${isAr ? 'معلق' : 'Req'}` : null,
      highlight: true,
    },
    {
      id: 'master-data' as ActiveTab,
      labelAr: 'البيانات المرجعية والمستخدمين',
      labelEn: 'Master Data & Users',
      icon: Database,
      roles: ['Admin', 'COO'],
      badge: null,
    },
  ];

  // In Driver View mode, restrict menu strictly to Operations Log and Transporter Performance
  const displayedMenuItems = isDriverMode
    ? menuItems.filter((item) => item.id === 'operations' || item.id === 'transporters')
    : menuItems;

  const handleToggleDriverView = () => {
    const nextState = !isDriverMode;
    toggleDriverMode();
    if (nextState && activeTab !== 'operations' && activeTab !== 'transporters') {
      setActiveTab('operations');
    }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        id="app-sidebar-navigation"
        className={`fixed top-18 z-40 h-[calc(100vh-4.5rem)] w-68 border-r border-neutral-200/80 bg-white transition-transform duration-300 lg:static lg:block ${
          isOpenMobile ? 'translate-x-0' : isAr ? 'translate-x-full lg:translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex h-full flex-col justify-between p-4">
          <div className="space-y-2">
            {/* Driver View Toggle Switch Banner */}
            <div className={`rounded-2xl border p-3 transition-all ${
              isDriverMode 
                ? 'border-orange-300 bg-gradient-to-r from-orange-50 to-amber-50 shadow-xs' 
                : 'border-neutral-200 bg-neutral-50/70 hover:bg-neutral-100/60'
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`flex h-7 w-7 items-center justify-center rounded-lg ${
                    isDriverMode ? 'bg-[#F05627] text-white shadow-xs' : 'bg-neutral-200 text-neutral-600'
                  }`}>
                    <Truck className="h-4 w-4" />
                  </div>
                  <div>
                    <span className="block text-xs font-black text-neutral-900">
                      {isAr ? 'وضع السائقين' : 'Driver View'}
                    </span>
                    <span className="block text-[10px] text-neutral-500 font-semibold">
                      {isDriverMode 
                        ? (isAr ? 'العمليات والناقلين فقط' : 'Operations & Logistics only')
                        : (isAr ? 'العرض الكامل للنظام' : 'Full ERP View')}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  id="driver-view-mode-toggle"
                  onClick={handleToggleDriverView}
                  className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    isDriverMode ? 'bg-[#F05627]' : 'bg-neutral-300'
                  }`}
                  aria-pressed={isDriverMode}
                  title={isAr ? 'تبديل وضع السائقين المبسط' : 'Toggle Driver View Mode'}
                >
                  <span
                    aria-hidden="true"
                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                      isDriverMode ? (isAr ? '-translate-x-4' : 'translate-x-4') : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {isDriverMode && (
                <div className="mt-2 rounded-lg bg-orange-500/10 px-2 py-1 text-[10px] font-bold text-[#F05627] flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#F05627] animate-pulse" />
                  <span>{isAr ? 'تم تقييد الواجهة للعمليات الميدانية' : 'UI restricted to Field & Logistics'}</span>
                </div>
              )}
            </div>

            <div className="px-1 pt-2">
              <span className="text-[11px] font-bold tracking-wider text-neutral-400 uppercase">
                {isDriverMode 
                  ? (isAr ? 'القائمة الميدانية المبسطة' : 'Field Operations') 
                  : (isAr ? 'القائمة الرئيسية' : 'Main Navigation')}
              </span>
            </div>

            <div className="space-y-1">
              {displayedMenuItems.map((item) => {
                const isAllowed = item.roles.includes(currentUser.role);
                const isActive = activeTab === item.id;
                const Icon = item.icon;

                if (!isAllowed) {
                  return (
                    <div
                      key={item.id}
                      className="flex cursor-not-allowed items-center justify-between rounded-xl px-3 py-2.5 text-neutral-300 opacity-60"
                    >
                      <div className="flex items-center gap-3">
                        <Icon className="h-4 w-4 text-neutral-300" />
                        <span className="text-xs font-semibold">
                          {isAr ? item.labelAr : item.labelEn}
                        </span>
                      </div>
                      <Lock className="h-3 w-3 text-neutral-300" />
                    </div>
                  );
                }

                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      if (onCloseMobile) onCloseMobile();
                    }}
                    className={`flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-xs font-bold transition-all ${
                      isActive
                        ? 'bg-gradient-to-r from-orange-600 to-orange-500 text-white shadow-md shadow-orange-500/20'
                        : item.highlight
                        ? 'bg-amber-50/70 text-amber-900 hover:bg-amber-100/80 border border-amber-200/60'
                        : 'text-neutral-600 hover:bg-neutral-50 hover:text-neutral-900'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className={`h-4 w-4 ${isActive ? 'text-white' : item.highlight ? 'text-amber-600' : 'text-neutral-500'}`} />
                      <span>{isAr ? item.labelAr : item.labelEn}</span>
                    </div>

                    {item.badge && (
                      <span
                        className={`rounded-md px-1.5 py-0.5 text-[10px] font-black ${
                          isActive
                            ? 'bg-white/20 text-white'
                            : item.highlight && kpis.pendingApprovalsCount > 0
                            ? 'bg-amber-500 text-white animate-pulse'
                            : 'bg-orange-50 text-[#F05627]'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* User Role Card in Sidebar */}
          <div className="rounded-2xl border border-neutral-200/80 bg-neutral-50 p-3">
            <div className="flex items-center gap-2.5">
              <img
                src={
                  currentUser.avatar ||
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'
                }
                alt={currentUser.fullName}
                className="h-9 w-9 rounded-xl object-cover ring-2 ring-orange-500/30"
              />
              <div className="overflow-hidden">
                <p className="truncate text-xs font-black text-neutral-900">
                  {currentUser.fullNameAr || currentUser.fullName}
                </p>
                <div className="flex items-center gap-1">
                  <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-500" />
                  <span className="text-[10px] font-bold text-[#F05627]">
                    {currentUser.role === 'Admin'
                      ? 'المدير التنفيذي CEO'
                      : currentUser.role === 'COO'
                      ? 'المدير التنفيذي للعمليات COO'
                      : currentUser.role === 'Accountant'
                      ? 'المحاسب المالي'
                      : currentUser.role === 'Data_Entry'
                      ? 'مدخل بيانات العمليات'
                      : 'بوابة العميل / مدقق'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
